package com.incerviewdot.demogitproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemogitprojectApplicationTests {

	@Test
	void contextLoads() {
	}

}
