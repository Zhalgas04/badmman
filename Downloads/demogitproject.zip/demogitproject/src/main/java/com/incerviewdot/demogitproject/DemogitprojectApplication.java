package com.incerviewdot.demogitproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemogitprojectApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemogitprojectApplication.class, args);
	}

}
